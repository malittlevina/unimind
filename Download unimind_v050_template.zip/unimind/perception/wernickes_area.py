# Wernickes Area.Py

